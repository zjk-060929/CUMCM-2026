"""问题三：先完成搜索与发现即处理的配对蒙特卡洛。

该程序只比较调度时机，两个策略共用：

* 同一批隐藏场景；
* 同一条七点保证性搜索路线；
* 同一频道扫描规则；
* 同一个第二检测点、半平面交和光学覆盖清除子程序。

策略 A 在七个覆盖点全部访问完后才定位、清除已发现源；策略 B 每到一个
覆盖点便对本点新发现的源滚动排序，立即定位、清除，然后继续覆盖路线。

重要：真实位置只封装在 Environment 中，用于产生测向读数和判定光学清除
是否成功；路线选择、第二点选择与清除点选择均不能读取真实位置。

仿真假设（题目没有给出概率分布，故只能用于策略筛选而非严格最优性证明）：

1. 源数在 10--16 上离散均匀，频道从 1--20 中无放回均匀抽取；
2. 源位置在半径 1800 m 圆盘内按面积均匀；
3. 有效接收半径在 1000--1500 m 均匀；
4. 不同地点的测角误差由确定性哈希生成，边际上近似 U[-1°,1°]，同一点
   重复测量误差不变；
5. 搜索阶段一旦发现某频道，后续覆盖点不再扫描该频道；因此两个策略为
   每个源取得完全相同类型的一次初始测量，差别主要来自任务执行次序；
6. 若两次测向后的最小包围圆半径仍大于 20 m，则以解析定位区域包围盒上的
   20 m 保守覆盖网格逐点启用光学探测，保证最终能够清除。
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.font_manager as font_manager
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
Q1_DIR = HERE.parent / "question2_final"
sys.path.insert(0, str(Q1_DIR))

from q1_localization import (  # noqa: E402
    LocalizationError,
    Measurement,
    build_bearing_halfplanes,
    half_plane_intersection,
    make_line,
)


REGION_RADIUS = 1800.0
MIN_RECEPTION_RADIUS = 1000.0
MAX_RECEPTION_RADIUS = 1500.0
BEARING_ERROR_DEG = 1.0
DOG_SPEED = 5.0
DETECT_TIME = 5.0
SWITCH_TIME = 1.0
OPTICAL_TIME = 3.0
CLEAR_TIME = 2.0
OPTICAL_RADIUS = 20.0
NEAR_RADIUS = 5.0
CHANNELS = tuple(range(1, 21))

Q2_FORWARD = 9000.0 / 11.0
Q2_LATERAL = 2000.0 * math.sqrt(10.0) / 11.0


def coverage_radius() -> float:
    """七个等角点中满足边界覆盖条件的较小解析根。"""

    angle = math.pi / 7.0
    return (
        REGION_RADIUS * math.cos(angle)
        - math.sqrt(
            MIN_RECEPTION_RADIUS**2
            - REGION_RADIUS**2 * math.sin(angle) ** 2
        )
    )


def coverage_stations() -> list[np.ndarray]:
    radius = coverage_radius()
    return [
        radius
        * np.array(
            [math.cos(2.0 * math.pi * k / 7.0), math.sin(2.0 * math.pi * k / 7.0)]
        )
        for k in range(7)
    ]


def bearing_deg(origin: np.ndarray, target: np.ndarray) -> float:
    delta = target - origin
    return math.degrees(math.atan2(float(delta[1]), float(delta[0]))) % 360.0


def location_error_deg(field_seed: int, point: np.ndarray) -> float:
    """同一场景、同一地点固定，换地点近似独立的有界误差场。"""

    key = f"{field_seed}:{point[0]:.6f}:{point[1]:.6f}".encode("utf-8")
    digest = hashlib.blake2b(key, digest_size=8).digest()
    unit = int.from_bytes(digest, "big") / float(2**64 - 1)
    return BEARING_ERROR_DEG * (2.0 * unit - 1.0)


@dataclass(frozen=True)
class HiddenSource:
    channel: int
    x: float
    y: float
    reception_radius: float

    @property
    def point(self) -> np.ndarray:
        return np.array([self.x, self.y], dtype=float)


@dataclass(frozen=True)
class Scenario:
    scenario_id: int
    field_seed: int
    sources: tuple[HiddenSource, ...]


@dataclass(frozen=True)
class Observation:
    point_x: float
    point_y: float
    bearing: float

    @property
    def point(self) -> np.ndarray:
        return np.array([self.point_x, self.point_y], dtype=float)


@dataclass(frozen=True)
class DetectReply:
    status: str  # no_signal, direction, near
    bearing: float | None = None


class Environment:
    """隐藏真实数据；策略只能调用 detect 与 optical。"""

    def __init__(self, scenario: Scenario):
        self._field_seed = scenario.field_seed
        self._sources = {source.channel: source for source in scenario.sources}
        self._cleared: set[int] = set()

    def detect(self, channel: int, point: np.ndarray) -> DetectReply:
        source = self._sources.get(channel)
        if source is None or channel in self._cleared:
            return DetectReply("no_signal")
        distance = float(np.linalg.norm(source.point - point))
        if distance > source.reception_radius + 1.0e-9:
            return DetectReply("no_signal")
        if distance <= NEAR_RADIUS + 1.0e-9:
            return DetectReply("near")
        measured = (
            bearing_deg(point, source.point)
            + location_error_deg(self._field_seed, point)
        ) % 360.0
        return DetectReply("direction", measured)

    def optical(self, channel: int, point: np.ndarray) -> bool:
        source = self._sources.get(channel)
        if source is None or channel in self._cleared:
            return False
        if float(np.linalg.norm(source.point - point)) <= OPTICAL_RADIUS + 1.0e-9:
            self._cleared.add(channel)
            return True
        return False

    @property
    def source_count(self) -> int:
        return len(self._sources)

    @property
    def cleared_count(self) -> int:
        return len(self._cleared)


@dataclass
class Dog:
    position: np.ndarray
    channel: int = 1
    time_s: float = 0.0
    path_m: float = 0.0
    switches: int = 0
    detections: int = 0
    optical_attempts: int = 0

    def move(self, target: np.ndarray) -> None:
        distance = float(np.linalg.norm(target - self.position))
        self.path_m += distance
        self.time_s += distance / DOG_SPEED
        self.position = np.array(target, dtype=float)

    def tune(self, channel: int) -> None:
        if channel != self.channel:
            self.time_s += SWITCH_TIME
            self.switches += 1
            self.channel = channel

    def detect(self, env: Environment, channel: int) -> DetectReply:
        self.tune(channel)
        self.time_s += DETECT_TIME
        self.detections += 1
        return env.detect(channel, self.position)

    def optical(self, env: Environment, channel: int) -> bool:
        self.time_s += OPTICAL_TIME
        self.optical_attempts += 1
        success = env.optical(channel, self.position)
        if success:
            self.time_s += CLEAR_TIME
        return success


def circle_halfplanes(
    center: np.ndarray, radius: float, sides: int = 32
) -> list:
    """用外切正多边形包住圆盘，不排除真实源。"""

    result = []
    for k in range(sides):
        angle = 2.0 * math.pi * k / sides
        normal = np.array([math.cos(angle), math.sin(angle)])
        tangent_point = center + radius * normal
        direction = np.array([-math.sin(angle), math.cos(angle)])
        result.append(make_line(tangent_point, direction))
    return result


TARGET_LINES = circle_halfplanes(np.zeros(2), REGION_RADIUS, sides=64)


def _circle_two(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, float]:
    center = 0.5 * (a + b)
    return center, float(np.linalg.norm(a - center))


def _circle_three(
    a: np.ndarray, b: np.ndarray, c: np.ndarray
) -> tuple[np.ndarray, float] | None:
    ax, ay = a
    bx, by = b
    cx, cy = c
    determinant = 2.0 * (
        ax * (by - cy) + bx * (cy - ay) + cx * (ay - by)
    )
    if abs(determinant) <= 1.0e-12:
        return None
    ux = (
        (ax * ax + ay * ay) * (by - cy)
        + (bx * bx + by * by) * (cy - ay)
        + (cx * cx + cy * cy) * (ay - by)
    ) / determinant
    uy = (
        (ax * ax + ay * ay) * (cx - bx)
        + (bx * bx + by * by) * (ax - cx)
        + (cx * cx + cy * cy) * (bx - ax)
    ) / determinant
    center = np.array([ux, uy])
    return center, float(np.linalg.norm(a - center))


def _contains(circle: tuple[np.ndarray, float], point: np.ndarray) -> bool:
    center, radius = circle
    return float(np.linalg.norm(point - center)) <= radius + 1.0e-7 * max(1.0, radius)


def minimum_enclosing_circle(points: np.ndarray) -> tuple[np.ndarray, float]:
    data = np.asarray(points, dtype=float)
    if len(data) == 0:
        raise ValueError("empty point set")
    order = data[np.random.default_rng(20260911 + len(data)).permutation(len(data))]
    circle: tuple[np.ndarray, float] | None = None
    for i, a in enumerate(order):
        if circle is not None and _contains(circle, a):
            continue
        circle = (a.copy(), 0.0)
        for j, b in enumerate(order[:i]):
            if _contains(circle, b):
                continue
            circle = _circle_two(a, b)
            for c in order[:j]:
                if _contains(circle, c):
                    continue
                triple = _circle_three(a, b, c)
                if triple is not None:
                    circle = triple
                else:
                    pairs = [_circle_two(a, b), _circle_two(a, c), _circle_two(b, c)]
                    circle = min(
                        (
                            candidate
                            for candidate in pairs
                            if all(_contains(candidate, p) for p in (a, b, c))
                        ),
                        key=lambda item: item[1],
                    )
    assert circle is not None
    return circle


def localization_polygon(observations: Sequence[Observation]) -> np.ndarray:
    lines = list(TARGET_LINES)
    measurements = [
        Measurement(obs.point_x, obs.point_y, obs.bearing) for obs in observations
    ]
    lines.extend(build_bearing_halfplanes(measurements, BEARING_ERROR_DEG))
    for obs in observations:
        lines.extend(circle_halfplanes(obs.point, MAX_RECEPTION_RADIUS, sides=32))
    return half_plane_intersection(lines, eps=1.0e-9)


def q2_candidates(observation: Observation) -> tuple[np.ndarray, np.ndarray]:
    theta = math.radians(observation.bearing)
    u = np.array([math.cos(theta), math.sin(theta)])
    v = np.array([-math.sin(theta), math.cos(theta)])
    base = observation.point + Q2_FORWARD * u
    return base + Q2_LATERAL * v, base - Q2_LATERAL * v


def choose_q2_point(
    dog_position: np.ndarray,
    observation: Observation,
    anchor: np.ndarray | None,
) -> np.ndarray:
    candidates = q2_candidates(observation)

    def score(point: np.ndarray) -> float:
        value = float(np.linalg.norm(point - dog_position))
        if anchor is not None:
            value += float(np.linalg.norm(anchor - point))
        return value

    return min(candidates, key=score)


def _axis(minimum: float, maximum: float) -> np.ndarray:
    width = maximum - minimum
    if width <= 1.0e-10:
        return np.array([(minimum + maximum) / 2.0])
    max_side = OPTICAL_RADIUS * math.sqrt(2.0) * 0.98
    count = max(1, int(math.ceil(width / max_side)))
    return minimum + (np.arange(count) + 0.5) * width / count


def _serpentine_grids(xs: np.ndarray, ys: np.ndarray) -> list[np.ndarray]:
    result = []
    for reverse_y in (False, True):
        rows = []
        ordered_y = ys[::-1] if reverse_y else ys
        for row, y in enumerate(ordered_y):
            ordered_x = xs[::-1] if row % 2 else xs
            rows.extend([[float(x), float(y)] for x in ordered_x])
        result.append(np.asarray(rows))
        result.append(np.asarray(rows[::-1]))
    return result


def _path_length(start: np.ndarray, points: np.ndarray) -> float:
    if len(points) == 0:
        return 0.0
    total = float(np.linalg.norm(points[0] - start))
    if len(points) > 1:
        total += float(np.sum(np.linalg.norm(np.diff(points, axis=0), axis=1)))
    return total


def clear_from_polygon(
    dog: Dog,
    env: Environment,
    channel: int,
    polygon: np.ndarray,
) -> None:
    center, radius = minimum_enclosing_circle(polygon)
    dog.move(center)
    if dog.optical(env, channel):
        return
    if radius <= OPTICAL_RADIUS + 1.0e-6:
        raise RuntimeError("保守最小包围圆内却未清除，定位约束实现有误")

    minimum = np.min(polygon, axis=0)
    maximum = np.max(polygon, axis=0)
    xs = _axis(float(minimum[0]), float(maximum[0]))
    ys = _axis(float(minimum[1]), float(maximum[1]))
    grids = _serpentine_grids(xs, ys)
    route = min(grids, key=lambda points: _path_length(dog.position, points))
    for point in route:
        dog.move(point)
        if dog.optical(env, channel):
            return
    raise RuntimeError("光学覆盖网格未清除源")


def service_source(
    dog: Dog,
    env: Environment,
    channel: int,
    initial: Observation,
    anchor: np.ndarray | None,
) -> None:
    """统一的“解析第二点 + HPI + 保守光学覆盖”子程序。"""

    second = choose_q2_point(dog.position, initial, anchor)
    dog.move(second)
    reply = dog.detect(env, channel)
    if reply.status == "near":
        if not dog.optical(env, channel):
            raise RuntimeError("near 回复后光学清除失败")
        return
    if reply.status != "direction" or reply.bearing is None:
        raise RuntimeError("解析安全第二点发生信号丢失")
    observations = [
        initial,
        Observation(float(second[0]), float(second[1]), float(reply.bearing)),
    ]
    try:
        polygon = localization_polygon(observations)
    except LocalizationError as exc:
        raise RuntimeError("半平面交失败") from exc
    clear_from_polygon(dog, env, channel, polygon)


def generated_scenarios(count: int, seed: int) -> list[Scenario]:
    rng = np.random.default_rng(seed)
    scenarios = []
    for scenario_id in range(count):
        source_count = int(rng.integers(10, 17))
        channels = rng.choice(np.array(CHANNELS), size=source_count, replace=False)
        sources = []
        for channel in channels:
            radius = REGION_RADIUS * math.sqrt(float(rng.random()))
            angle = float(rng.uniform(0.0, 2.0 * math.pi))
            sources.append(
                HiddenSource(
                    int(channel),
                    radius * math.cos(angle),
                    radius * math.sin(angle),
                    float(rng.uniform(MIN_RECEPTION_RADIUS, MAX_RECEPTION_RADIUS)),
                )
            )
        scenarios.append(
            Scenario(
                scenario_id=scenario_id,
                field_seed=int(rng.integers(0, 2**31 - 1)),
                sources=tuple(sources),
            )
        )
    return scenarios


@dataclass(frozen=True)
class PolicyOutcome:
    policy: str
    scenario_id: int
    source_count: int
    cleared_count: int
    total_time_s: float
    average_time_s: float
    path_m: float
    detections: int
    switches: int
    optical_attempts: int


def _task_score(
    dog: Dog,
    observation: Observation,
    anchor: np.ndarray | None,
) -> float:
    point = choose_q2_point(dog.position, observation, anchor)
    value = float(np.linalg.norm(point - dog.position))
    if anchor is not None:
        value += float(np.linalg.norm(anchor - point))
    return value


def simulate_policy(scenario: Scenario, policy: str) -> PolicyOutcome:
    if policy not in {"search_first", "interleaved"}:
        raise ValueError(policy)
    env = Environment(scenario)
    dog = Dog(position=np.zeros(2))
    stations = coverage_stations()
    discovered: set[int] = set()
    observations: dict[int, Observation] = {}

    for station_index, station in enumerate(stations):
        reached_known_upper_bound = False
        dog.move(station)
        scan_channels = [channel for channel in CHANNELS if channel not in discovered]
        if station_index % 2:
            scan_channels.reverse()
        newly_discovered = []
        for channel in scan_channels:
            reply = dog.detect(env, channel)
            if reply.status == "direction" and reply.bearing is not None:
                discovered.add(channel)
                observations[channel] = Observation(
                    float(station[0]), float(station[1]), float(reply.bearing)
                )
                newly_discovered.append(channel)
            elif reply.status == "near":
                discovered.add(channel)
                if not dog.optical(env, channel):
                    raise RuntimeError("near 回复后未能清除")
            # 题面给出源数至多为 16；发现 16 个不同频道后可以由可观测
            # 状态证明不存在第 17 个源，无需读取隐藏的 source_count。
            if len(discovered) == 16:
                reached_known_upper_bound = True
                break

        if policy == "interleaved":
            anchor = (
                stations[station_index + 1]
                if not reached_known_upper_bound and station_index + 1 < len(stations)
                else None
            )
            pending = list(newly_discovered)
            while pending:
                channel = min(
                    pending,
                    key=lambda item: _task_score(dog, observations[item], anchor),
                )
                service_source(dog, env, channel, observations[channel], anchor)
                pending.remove(channel)

        if reached_known_upper_bound:
            break

    if policy == "search_first":
        # 只有 direction 回复会进入 observations；near 情形已在覆盖点原地清除，
        # 因而无需、也不允许策略读取 Environment 的隐藏清除集合。
        pending = list(observations)
        while pending:
            channel = min(
                pending,
                key=lambda item: _task_score(dog, observations[item], None),
            )
            service_source(dog, env, channel, observations[channel], None)
            pending.remove(channel)

    if env.cleared_count != env.source_count:
        raise RuntimeError(
            f"未全部清除：{env.cleared_count}/{env.source_count}; policy={policy}"
        )
    return PolicyOutcome(
        policy=policy,
        scenario_id=scenario.scenario_id,
        source_count=env.source_count,
        cleared_count=env.cleared_count,
        total_time_s=dog.time_s,
        average_time_s=dog.time_s / env.cleared_count,
        path_m=dog.path_m,
        detections=dog.detections,
        switches=dog.switches,
        optical_attempts=dog.optical_attempts,
    )


def paired_bootstrap_ci(
    values: np.ndarray, seed: int, repetitions: int = 5000
) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    n = len(values)
    samples = np.empty(repetitions)
    for i in range(repetitions):
        samples[i] = float(np.mean(values[rng.integers(0, n, size=n)]))
    return float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def summarize(outcomes: Sequence[PolicyOutcome]) -> dict[str, object]:
    by_policy = {
        policy: [item for item in outcomes if item.policy == policy]
        for policy in ("search_first", "interleaved")
    }
    summary: dict[str, object] = {}
    for policy, rows in by_policy.items():
        times = np.array([row.total_time_s for row in rows])
        summary[policy] = {
            "scenarios": len(rows),
            "full_clear_rate": float(
                np.mean([row.cleared_count == row.source_count for row in rows])
            ),
            "mean_total_time_s": float(np.mean(times)),
            "median_total_time_s": float(np.median(times)),
            "p90_total_time_s": float(np.quantile(times, 0.90)),
            "mean_average_time_s_per_source": float(
                np.mean([row.average_time_s for row in rows])
            ),
            "mean_path_m": float(np.mean([row.path_m for row in rows])),
            "mean_detections": float(np.mean([row.detections for row in rows])),
            "mean_switches": float(np.mean([row.switches for row in rows])),
            "mean_optical_attempts": float(
                np.mean([row.optical_attempts for row in rows])
            ),
        }
    first = {row.scenario_id: row for row in by_policy["search_first"]}
    rolling = {row.scenario_id: row for row in by_policy["interleaved"]}
    differences = np.array(
        [rolling[index].total_time_s - first[index].total_time_s for index in sorted(first)]
    )
    ci = paired_bootstrap_ci(differences, seed=20260911)
    summary["paired_interleaved_minus_search_first"] = {
        "mean_time_difference_s": float(np.mean(differences)),
        "median_time_difference_s": float(np.median(differences)),
        "p10_time_difference_s": float(np.quantile(differences, 0.10)),
        "p90_time_difference_s": float(np.quantile(differences, 0.90)),
        "mean_95pct_bootstrap_ci_s": [ci[0], ci[1]],
        "interleaved_faster_rate": float(np.mean(differences < 0.0)),
    }
    summary["coverage"] = {
        "station_count": 7,
        "station_radius_m": coverage_radius(),
        "guaranteed_detection_radius_m": MIN_RECEPTION_RADIUS,
    }
    return summary


def configure_font() -> None:
    for filename in ("msyh.ttc", "simhei.ttf", "simsun.ttc"):
        path = Path(r"C:\Windows\Fonts") / filename
        if path.exists():
            font_manager.fontManager.addfont(path)
            plt.rcParams["font.family"] = font_manager.FontProperties(fname=path).get_name()
            break
    plt.rcParams["axes.unicode_minus"] = False


def make_figure(outcomes: Sequence[PolicyOutcome]) -> None:
    configure_font()
    first = sorted(
        (row for row in outcomes if row.policy == "search_first"),
        key=lambda row: row.scenario_id,
    )
    rolling = sorted(
        (row for row in outcomes if row.policy == "interleaved"),
        key=lambda row: row.scenario_id,
    )
    first_times = np.array([row.total_time_s for row in first])
    rolling_times = np.array([row.total_time_s for row in rolling])
    difference = rolling_times - first_times

    figure, axes = plt.subplots(1, 2, figsize=(12.0, 4.8))
    axes[0].boxplot(
        [first_times, rolling_times],
        tick_labels=["完成七点后处理", "发现后立即处理"],
        showfliers=False,
        patch_artist=True,
        boxprops=dict(facecolor="#dbeafe", edgecolor="#2563eb"),
        medianprops=dict(color="#dc2626", linewidth=1.8),
    )
    axes[0].set_ylabel("单场景总虚拟时间 / s")
    axes[0].set_title("同一隐藏场景上的总时间")
    axes[0].grid(axis="y", alpha=0.22)

    axes[1].hist(difference, bins=32, color="#0f766e", alpha=0.82)
    axes[1].axvline(0.0, color="black", linestyle="--", linewidth=1.1)
    axes[1].axvline(float(np.mean(difference)), color="#dc2626", linewidth=1.5)
    axes[1].set_xlabel("发现即处理 − 七点后处理 / s")
    axes[1].set_ylabel("场景数")
    axes[1].set_title(f"配对差值（均值 {np.mean(difference):.1f} s）")
    axes[1].grid(axis="y", alpha=0.22)
    figure.tight_layout()
    figure.savefig(HERE / "policy_sim_comparison.png", dpi=260, bbox_inches="tight")
    plt.close(figure)


def write_outputs(outcomes: Sequence[PolicyOutcome], summary: dict[str, object]) -> None:
    with (HERE / "policy_sim_samples.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(outcomes[0])))
        writer.writeheader()
        writer.writerows(asdict(row) for row in outcomes)
    with (HERE / "policy_sim_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    make_figure(outcomes)


def verify_coverage(samples_r: int = 301, samples_angle: int = 1440) -> float:
    """仅作数值回归检查；解析保证由论文中的距离凸性证明给出。"""

    stations = coverage_stations()
    maximum_nearest = 0.0
    for radius in np.linspace(0.0, REGION_RADIUS, samples_r):
        for angle in np.linspace(0.0, 2.0 * math.pi, samples_angle, endpoint=False):
            point = radius * np.array([math.cos(angle), math.sin(angle)])
            nearest = min(float(np.linalg.norm(point - station)) for station in stations)
            maximum_nearest = max(maximum_nearest, nearest)
    return maximum_nearest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenarios", type=int, default=500)
    parser.add_argument("--seed", type=int, default=20260911)
    args = parser.parse_args()

    maximum_nearest = verify_coverage(samples_r=61, samples_angle=420)
    if maximum_nearest > MIN_RECEPTION_RADIUS + 0.2:
        raise RuntimeError(f"七点覆盖数值检查失败: {maximum_nearest}")

    scenarios = generated_scenarios(args.scenarios, args.seed)
    outcomes: list[PolicyOutcome] = []
    for index, scenario in enumerate(scenarios):
        outcomes.append(simulate_policy(scenario, "search_first"))
        outcomes.append(simulate_policy(scenario, "interleaved"))
        if (index + 1) % 50 == 0:
            print(f"completed {index + 1}/{len(scenarios)}", flush=True)
    summary = summarize(outcomes)
    summary["coverage"]["numerical_max_nearest_distance_m"] = maximum_nearest
    write_outputs(outcomes, summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
