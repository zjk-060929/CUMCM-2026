"""在既有 500 个场景上评估无经验阈值的机会式滚动启发式。

启发规则：对每个已发现但未处理的源，仅用其首次示向度构造问题二的两个
第二检测点。把第二检测点当作服务任务的入口，计算将该入口插入当前以及
未来每一条七点骨架边的额外路程。如果当前边是所有剩余骨架边中最便宜的
插入位置，才立即执行；否则等待下一覆盖点后重新计算。最后一个覆盖点后
统一处理仍未执行的任务。

该规则没有人为阈值，但入口点只是完整定位清除任务的几何代理，因此属于
可复现的机会式启发式，不是全局最优算法。
"""

from __future__ import annotations

import csv
import json
import math
from dataclasses import asdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.font_manager as font_manager
import matplotlib.pyplot as plt
import numpy as np

from q3_policy_monte_carlo import (
    CHANNELS,
    Environment,
    Dog,
    Observation,
    PolicyOutcome,
    Scenario,
    _task_score,
    coverage_stations,
    generated_scenarios,
    paired_bootstrap_ci,
    q2_candidates,
    service_source,
)


HERE = Path(__file__).resolve().parent
SCENARIOS = 500
SEED = 20260911


def insertion_cost(start: np.ndarray, end: np.ndarray, obs: Observation) -> float:
    direct = float(np.linalg.norm(end - start))
    return min(
        float(np.linalg.norm(point - start) + np.linalg.norm(end - point) - direct)
        for point in q2_candidates(obs)
    )


def current_edge_is_cheapest(
    dog_position: np.ndarray,
    station_index: int,
    stations: list[np.ndarray],
    obs: Observation,
) -> tuple[bool, float]:
    """返回当前边是否为剩余骨架上最便宜插入边及当前插入量。"""

    if station_index + 1 >= len(stations):
        return True, 0.0
    costs = [insertion_cost(dog_position, stations[station_index + 1], obs)]
    for edge_start in range(station_index + 1, len(stations) - 1):
        costs.append(
            insertion_cost(stations[edge_start], stations[edge_start + 1], obs)
        )
    tolerance = 1.0e-9 * max(1.0, max(costs))
    return costs[0] <= min(costs) + tolerance, costs[0]


def simulate_opportunistic(scenario: Scenario) -> PolicyOutcome:
    env = Environment(scenario)
    dog = Dog(position=np.zeros(2))
    stations = coverage_stations()
    discovered: set[int] = set()
    observations: dict[int, Observation] = {}
    pending: list[int] = []

    for station_index, station in enumerate(stations):
        reached_known_upper_bound = False
        dog.move(station)
        scan_channels = [channel for channel in CHANNELS if channel not in discovered]
        if station_index % 2:
            scan_channels.reverse()
        for channel in scan_channels:
            reply = dog.detect(env, channel)
            if reply.status == "direction" and reply.bearing is not None:
                discovered.add(channel)
                observations[channel] = Observation(
                    float(station[0]), float(station[1]), float(reply.bearing)
                )
                pending.append(channel)
            elif reply.status == "near":
                discovered.add(channel)
                if not dog.optical(env, channel):
                    raise RuntimeError("near 回复后未能清除")
            if len(discovered) == 16:
                reached_known_upper_bound = True
                break

        if reached_known_upper_bound:
            # 只依据已发现的 16 个不同频道和题面上限停止覆盖；待处理任务
            # 随后由统一尾段路线完成，不读取隐藏真实源数。
            break

        if station_index + 1 < len(stations):
            anchor = stations[station_index + 1]
            while pending:
                eligible: list[tuple[float, int]] = []
                for channel in pending:
                    is_cheapest, extra = current_edge_is_cheapest(
                        dog.position, station_index, stations, observations[channel]
                    )
                    if is_cheapest:
                        eligible.append((extra, channel))
                if not eligible:
                    break
                _, channel = min(eligible)
                service_source(dog, env, channel, observations[channel], anchor)
                pending.remove(channel)

    while pending:
        channel = min(
            pending,
            key=lambda item: _task_score(dog, observations[item], None),
        )
        service_source(dog, env, channel, observations[channel], None)
        pending.remove(channel)

    if env.cleared_count != env.source_count:
        raise RuntimeError(
            f"未全部清除：{env.cleared_count}/{env.source_count}; opportunistic"
        )
    return PolicyOutcome(
        policy="opportunistic",
        scenario_id=scenario.scenario_id,
        source_count=env.source_count,
        cleared_count=env.cleared_count,
        total_time_s=dog.time_s,
        average_time_s=dog.time_s / env.cleared_count,
        path_m=dog.path_m,
        detections=dog.detections,
        switches=dog.switches,
        optical_attempts=dog.optical_attempts,
    )


def load_baselines() -> dict[str, dict[int, dict[str, float]]]:
    path = HERE / "policy_sim_samples.csv"
    result: dict[str, dict[int, dict[str, float]]] = {
        "search_first": {},
        "interleaved": {},
    }
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            policy = row["policy"]
            scenario_id = int(row["scenario_id"])
            result[policy][scenario_id] = {
                key: float(value)
                for key, value in row.items()
                if key not in {"policy", "scenario_id"}
            }
    if any(len(rows) != SCENARIOS for rows in result.values()):
        raise RuntimeError("既有基线并非相同的 500 场结果")
    return result


def metric_summary(rows: list[PolicyOutcome]) -> dict[str, float]:
    times = np.array([row.total_time_s for row in rows])
    return {
        "scenarios": len(rows),
        "full_clear_rate": float(
            np.mean([row.cleared_count == row.source_count for row in rows])
        ),
        "mean_total_time_s": float(np.mean(times)),
        "median_total_time_s": float(np.median(times)),
        "p90_total_time_s": float(np.quantile(times, 0.90)),
        "mean_average_time_s_per_source": float(
            np.mean([row.average_time_s for row in rows])
        ),
        "mean_path_m": float(np.mean([row.path_m for row in rows])),
        "mean_detections": float(np.mean([row.detections for row in rows])),
        "mean_switches": float(np.mean([row.switches for row in rows])),
        "mean_optical_attempts": float(np.mean([row.optical_attempts for row in rows])),
    }


def compare_to(
    rows: list[PolicyOutcome], baseline: dict[int, dict[str, float]], seed: int
) -> dict[str, object]:
    differences = np.array(
        [row.total_time_s - baseline[row.scenario_id]["total_time_s"] for row in rows]
    )
    ci = paired_bootstrap_ci(differences, seed=seed)
    return {
        "mean_time_difference_s": float(np.mean(differences)),
        "median_time_difference_s": float(np.median(differences)),
        "mean_95pct_bootstrap_ci_s": [ci[0], ci[1]],
        "opportunistic_faster_rate": float(np.mean(differences < 0.0)),
    }


def configure_font() -> None:
    for filename in ("msyh.ttc", "simhei.ttf", "simsun.ttc"):
        path = Path(r"C:\Windows\Fonts") / filename
        if path.exists():
            font_manager.fontManager.addfont(path)
            plt.rcParams["font.family"] = font_manager.FontProperties(fname=path).get_name()
            break
    plt.rcParams["axes.unicode_minus"] = False


def make_figure(
    rows: list[PolicyOutcome], baselines: dict[str, dict[int, dict[str, float]]]
) -> None:
    configure_font()
    ordered = sorted(rows, key=lambda row: row.scenario_id)
    values = [
        np.array(
            [baselines["search_first"][i]["total_time_s"] for i in range(SCENARIOS)]
        ),
        np.array([row.total_time_s for row in ordered]),
        np.array(
            [baselines["interleaved"][i]["total_time_s"] for i in range(SCENARIOS)]
        ),
    ]
    figure, axis = plt.subplots(figsize=(8.4, 5.2))
    boxes = axis.boxplot(
        values,
        tick_labels=["七点后处理", "机会式滚动", "发现即处理"],
        showfliers=False,
        patch_artist=True,
        medianprops=dict(color="#dc2626", linewidth=1.8),
    )
    for box, color in zip(boxes["boxes"], ("#bfdbfe", "#bbf7d0", "#fed7aa")):
        box.set_facecolor(color)
    axis.set_ylabel("单场景总虚拟时间 / s")
    axis.set_title("500 个相同隐藏场景上的调度时机")
    axis.grid(axis="y", alpha=0.22)
    figure.tight_layout()
    figure.savefig(HERE / "opportunistic_sim_comparison.png", dpi=260, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    baselines = load_baselines()
    scenarios = generated_scenarios(SCENARIOS, SEED)
    rows = []
    for index, scenario in enumerate(scenarios):
        rows.append(simulate_opportunistic(scenario))
        if (index + 1) % 50 == 0:
            print(f"completed {index + 1}/{SCENARIOS}", flush=True)

    summary = {
        "policy": "无经验阈值的机会式滚动启发式（非全局最优）",
        "seed": SEED,
        "opportunistic": metric_summary(rows),
        "opportunistic_minus_search_first": compare_to(
            rows, baselines["search_first"], seed=20260912
        ),
        "opportunistic_minus_immediate_interleaved": compare_to(
            rows, baselines["interleaved"], seed=20260913
        ),
    }
    with (HERE / "opportunistic_sim_samples.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0])))
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)
    with (HERE / "opportunistic_sim_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    make_figure(rows, baselines)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
