"""问题 3 演练策略：七点保证发现，随后集中定位并清除。"""

from __future__ import annotations

import math
import time
from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np

from geometry import (
    GeometryError,
    Observation,
    conservative_clear_route,
    coverage_stations,
    localization_polygon,
    ordered_second_detection_candidates,
)
from protocol import JsonlLogger, SimulatorClient


DOG_SPEED_MPS = 5.0
CHANNELS = tuple(range(1, 21))
MIN_SOURCE_COUNT = 10
MAX_SOURCE_COUNT = 16
# 由客户端允许的最坏配置推导：两个串行动作（当前动作和 /exit），
# 每个动作最多 3 次尝试，每次最多 5 秒，即 2×3×5=30 秒。
MIN_REAL_RESERVE_S = 30.0


class PolicyError(RuntimeError):
    """策略无法在可证明安全的状态下继续。"""


class TimeBudgetReached(PolicyError):
    """为正常 /exit 保留时间而主动停止新动作。"""


@dataclass
class RobotState:
    position: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=float))
    receiver_channel: int = 1
    virtual_time_s: float = 0.0
    measure_count: int = 0
    clear_attempt_count: int = 0
    clear_success_count: int = 0


@dataclass(frozen=True)
class RunSummary:
    strategy: str
    completed_normally: bool
    stop_reason: str
    stations_visited: int
    discovered_channels: tuple[int, ...]
    cleared_channels: tuple[int, ...]
    pending_channels: tuple[int, ...]
    measure_count: int
    clear_attempt_count: int
    clear_success_count: int
    final_virtual_time_s: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class TimeBudget:
    """由 /enter 实际返回值构造，不把 1200 秒写死。"""

    def __init__(
        self,
        remaining_real_duration_s: float,
        max_virtual_duration_s: float,
        client: SimulatorClient,
    ):
        if remaining_real_duration_s < 0 or max_virtual_duration_s <= 0:
            raise ValueError("模拟器返回了非法时间上限")
        if client.last_action_started_monotonic_s is None:
            raise ValueError("缺少 /enter 请求开始时刻")
        # 以客户端首次发送 /enter 的时刻为基准，比按响应到达时刻计算更保守。
        self.real_deadline = (
            client.last_action_started_monotonic_s + float(remaining_real_duration_s)
        )
        self.max_virtual_duration_s = float(max_virtual_duration_s)
        self.request_wait_s = client.worst_case_request_wait_s

    def check_new_action(self, predicted_virtual_finish_s: float) -> None:
        # 一个新动作最多等待 request_wait_s，之后还需为 /exit 保留同样的最坏等待时间。
        required_real_s = max(MIN_REAL_RESERVE_S, 2.0 * self.request_wait_s)
        if self.real_deadline - time.monotonic() <= required_real_s:
            raise TimeBudgetReached("现实时间仅够保留 /exit，不再发送新的测量或清除动作")
        if predicted_virtual_finish_s >= self.max_virtual_duration_s:
            raise TimeBudgetReached("下一动作可能触及虚拟时间上限")


class SearchFirstPolicy:
    """只适用于问题 3 的全向干扰源演练。"""

    name = "p3_search_first"

    def __init__(
        self,
        client: SimulatorClient,
        logger: JsonlLogger,
        enter_response: dict[str, Any],
    ):
        self.client = client
        self.logger = logger
        self.state = RobotState()
        self.budget = TimeBudget(
            float(enter_response["remaining_real_duration_s"]),
            float(enter_response["max_virtual_duration_s"]),
            client,
        )
        self.observations: dict[int, list[Observation]] = {}
        self.discovered: set[int] = set()
        self.cleared: set[int] = set()
        self.stations_visited = 0

    def _move_time(self, target: np.ndarray) -> float:
        return float(np.linalg.norm(target - self.state.position)) / DOG_SPEED_MPS

    def _measure(self, target: np.ndarray, channel: int) -> dict[str, Any]:
        predicted = (
            self.state.virtual_time_s
            + self._move_time(target)
            + (1.0 if channel != self.state.receiver_channel else 0.0)
            + 5.0
        )
        self.budget.check_new_action(predicted)
        response = self.client.measure(float(target[0]), float(target[1]), channel)
        self.state.position = np.array(target, dtype=float)
        self.state.receiver_channel = channel
        self.state.virtual_time_s = float(response["virtual_time_s"])
        self.state.measure_count += 1
        self.logger.write(
            "policy_measure",
            channel=channel,
            position=target.tolist(),
            result=response["measure_result"],
            bearing_deg=response.get("svd_deg"),
            virtual_time_s=self.state.virtual_time_s,
        )
        return response

    def _clear(self, target: np.ndarray, channel: int) -> bool:
        # 成功清除耗时 5 秒，比未发现的 3 秒更长，故用 5 秒作上界。
        predicted = self.state.virtual_time_s + self._move_time(target) + 5.0
        self.budget.check_new_action(predicted)
        response = self.client.clear(float(target[0]), float(target[1]), channel)
        self.state.position = np.array(target, dtype=float)
        self.state.virtual_time_s = float(response["virtual_time_s"])
        self.state.clear_attempt_count += 1
        success = response["clear_result"] == "success"
        if success:
            self.state.clear_success_count += 1
            self.cleared.add(channel)
        self.logger.write(
            "policy_clear",
            channel=channel,
            position=target.tolist(),
            result=response["clear_result"],
            virtual_time_s=self.state.virtual_time_s,
        )
        return success

    def _record_direction(
        self, channel: int, point: np.ndarray, response: dict[str, Any]
    ) -> Observation:
        observation = Observation(
            float(point[0]), float(point[1]), float(response["svd_deg"])
        )
        self.observations.setdefault(channel, []).append(observation)
        self.discovered.add(channel)
        return observation

    def _clear_near(self, channel: int, point: np.ndarray) -> None:
        self.discovered.add(channel)
        if not self._clear(point, channel):
            raise PolicyError(
                f"频道 {channel} 返回 near，但在同一点调用 /clear 没有成功"
            )

    def _scan_coverage_stations(self) -> None:
        for station_index, station in enumerate(coverage_stations()):
            unknown = [channel for channel in CHANNELS if channel not in self.discovered]
            if self.state.receiver_channel in unknown:
                unknown.remove(self.state.receiver_channel)
                unknown.insert(0, self.state.receiver_channel)

            self.logger.write(
                "station_start",
                station_index=station_index + 1,
                position=station.tolist(),
                channels_to_scan=unknown,
            )
            for channel in unknown:
                response = self._measure(station, channel)
                result = response["measure_result"]
                if result == "direction":
                    self._record_direction(channel, station, response)
                elif result == "near":
                    self._clear_near(channel, station)

                # 题面给出的干扰源数量上限是 16；发现 16 个后可证明没有第 17 个。
                if len(self.discovered) == MAX_SOURCE_COUNT:
                    break

            self.stations_visited += 1
            self.logger.write(
                "station_complete",
                station_index=station_index + 1,
                discovered_channels=sorted(self.discovered),
                cleared_channels=sorted(self.cleared),
                virtual_time_s=self.state.virtual_time_s,
            )
            if len(self.discovered) == MAX_SOURCE_COUNT:
                self.logger.write("coverage_early_stop", reason="已发现题面上限 16 个频道")
                break

    def _entry_distance(self, channel: int) -> float:
        first = self.observations[channel][0]
        return min(
            float(np.linalg.norm(point - self.state.position))
            for point in ordered_second_detection_candidates(self.state.position, first)
        )

    def _service_channel(self, channel: int) -> None:
        observations = self.observations[channel]
        first = observations[0]
        candidates = ordered_second_detection_candidates(self.state.position, first)
        polygon: np.ndarray | None = None
        last_geometry_error: GeometryError | None = None

        for candidate_index, candidate in enumerate(candidates, 1):
            response = self._measure(candidate, channel)
            result = response["measure_result"]
            if result == "near":
                self._clear_near(channel, candidate)
                return
            if result == "no_signal":
                self.logger.write(
                    "second_point_no_signal",
                    channel=channel,
                    candidate_index=candidate_index,
                    position=candidate.tolist(),
                )
                continue

            self._record_direction(channel, candidate, response)
            try:
                polygon = localization_polygon(observations)
                break
            except GeometryError as error:
                last_geometry_error = error
                self.logger.write(
                    "localization_retry",
                    channel=channel,
                    candidate_index=candidate_index,
                    error=error,
                )

        if polygon is None:
            detail = f": {last_geometry_error}" if last_geometry_error else ""
            raise PolicyError(f"频道 {channel} 的安全第二点未形成定位区域{detail}")

        route, enclosing_radius = conservative_clear_route(
            polygon, self.state.position
        )
        self.logger.write(
            "localization_complete",
            channel=channel,
            observation_count=len(observations),
            polygon_vertices=polygon.tolist(),
            enclosing_radius_m=enclosing_radius,
            clear_route_points=len(route),
        )
        for point in route:
            if self._clear(point, channel):
                return
        raise PolicyError(f"频道 {channel} 的保守覆盖路线走完后仍未清除")

    def run(self) -> RunSummary:
        self._scan_coverage_stations()
        if len(self.discovered) < MIN_SOURCE_COUNT:
            raise PolicyError(
                f"完成七点覆盖后仅发现 {len(self.discovered)} 个频道，"
                "低于问题3规定的最少10个；停止并保留日志检查"
            )
        pending = set(self.observations) - self.cleared
        while pending:
            channel = min(pending, key=self._entry_distance)
            self._service_channel(channel)
            pending.remove(channel)

        summary = RunSummary(
            strategy=self.name,
            completed_normally=True,
            stop_reason="所有已发现频道均已清除",
            stations_visited=self.stations_visited,
            discovered_channels=tuple(sorted(self.discovered)),
            cleared_channels=tuple(sorted(self.cleared)),
            pending_channels=(),
            measure_count=self.state.measure_count,
            clear_attempt_count=self.state.clear_attempt_count,
            clear_success_count=self.state.clear_success_count,
            final_virtual_time_s=self.state.virtual_time_s,
        )
        self.logger.write("policy_complete", summary=summary.as_dict())
        return summary

    def interrupted_summary(self, reason: str) -> RunSummary:
        pending = set(self.observations) - self.cleared
        return RunSummary(
            strategy=self.name,
            completed_normally=False,
            stop_reason=reason,
            stations_visited=self.stations_visited,
            discovered_channels=tuple(sorted(self.discovered)),
            cleared_channels=tuple(sorted(self.cleared)),
            pending_channels=tuple(sorted(pending)),
            measure_count=self.state.measure_count,
            clear_attempt_count=self.state.clear_attempt_count,
            clear_success_count=self.state.clear_success_count,
            final_virtual_time_s=self.state.virtual_time_s,
        )
