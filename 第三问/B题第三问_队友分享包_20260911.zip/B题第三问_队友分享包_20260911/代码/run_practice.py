"""问题 3 演练专用入口。

默认模式绝不访问网络。只有同时满足配置门禁、命令行门禁和人工确认门禁，
程序才会连接本机模拟器。程序不包含任何界面点击或正式测试控制逻辑。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import sys
import time
import uuid
from pathlib import Path
from typing import Any

from geometry import coverage_stations, minimax_coverage_radius, worst_coverage_distance
from policy import RunSummary, SearchFirstPolicy
from protocol import (
    ClientSettings,
    JsonlLogger,
    SimulatorClient,
)


HERE = Path(__file__).resolve().parent
DEFAULT_CONFIG = HERE / "config.json"
ALLOWED_CONFIG_KEYS = {
    "robot_id",
    "port",
    "timeout_s",
    "network_retries",
    "allow_live_practice",
    "log_directory",
}


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    if not isinstance(config, dict):
        raise ValueError("config.json 顶层必须是 JSON 对象")
    unknown = set(config) - ALLOWED_CONFIG_KEYS
    if unknown:
        raise ValueError(f"config.json 含未知字段: {sorted(unknown)}")
    required = {"robot_id", "port", "timeout_s", "network_retries", "allow_live_practice"}
    missing = required - set(config)
    if missing:
        raise ValueError(f"config.json 缺少字段: {sorted(missing)}")
    if not isinstance(config["allow_live_practice"], bool):
        raise ValueError("allow_live_practice 必须是 true 或 false")
    return config


def safe_case_tag(case_code: str) -> str:
    tag = re.sub(r"[^A-Za-z0-9_-]+", "-", case_code).strip("-")
    return (tag or "case")[:32]


def print_dry_run(config_path: Path, config: dict[str, Any]) -> None:
    print("离线检查模式：不会建立网络连接，也不会调用 /enter。")
    print(f"配置文件：{config_path}")
    print(f"当前端口：{config['port']}")
    print(f"实时演练门禁：{config['allow_live_practice']}")
    print(f"七点解析半径：{minimax_coverage_radius():.6f} m")
    print(f"最坏最近距离：{worst_coverage_distance():.6f} m")
    print("七个检测点：")
    for index, point in enumerate(coverage_stations(), 1):
        print(f"  H{index}: ({point[0]:.6f}, {point[1]:.6f})")
    if config["robot_id"] == "YOUR_TEAM_ID":
        print("尚未填写 robot_id；这是安全的，实时演练前再填写。")


def require_practice_confirmation(case_code: str) -> None:
    one_time_token = secrets.token_hex(2).upper()
    expected = f"P3-PRACTICE {case_code} {one_time_token}"
    print()
    print("================ 只允许问题3演练测试 ================")
    print("请逐项看当前会话界面，不要凭记忆确认：")
    print("1. 会话标题明确是“问题3 演练 测试”，其中“演练”为绿色；")
    print("2. 左侧“演练测试”处于高亮，左侧“正式测试”入口未高亮且未点击；")
    print("3. 5秒倒计时已经结束，右上状态为“等待机器狗进入”；")
    print("4. “机器狗程序剩余时间”为“尚未进入”；")
    print(f"5. 当前测试案例编码正是 {case_code}，不是 XXXX 占位符。")
    print("任一项不满足：直接关闭本程序，不要输入确认词。")
    print(f"五项全部满足时，输入：{expected}")
    actual = input("> ").strip()
    if actual != expected:
        raise SystemExit("确认词不匹配；已在发送任何网络请求之前退出。")


def consume_live_gate(config_path: Path, config: dict[str, Any]) -> None:
    """把实时许可原子复位为 false，使每次演练都必须重新人工开启。"""

    lock_path = config_path.with_name(f".{config_path.name}.practice-live.lock")
    try:
        lock_descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise SystemExit(
            "检测到另一份客户端正在消耗演练许可；本程序在联网前退出。"
        ) from error

    temporary = config_path.with_name(
        f".{config_path.name}.{uuid.uuid4().hex}.practice-gate.tmp"
    )
    try:
        os.write(lock_descriptor, str(os.getpid()).encode("ascii"))
        os.close(lock_descriptor)
        lock_descriptor = -1
        current = load_config(config_path)
        if current != config:
            raise SystemExit("确认期间 config.json 已发生变化；本程序在联网前退出")
        if not current["allow_live_practice"]:
            raise SystemExit("本次演练许可已被另一进程消耗；本程序在联网前退出")
        updated = dict(current)
        updated["allow_live_practice"] = False
        temporary.write_text(
            json.dumps(updated, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        temporary.replace(config_path)
    finally:
        if lock_descriptor >= 0:
            os.close(lock_descriptor)
        if temporary.exists():
            temporary.unlink()
        if lock_path.exists():
            lock_path.unlink()


def write_summary(
    path: Path,
    summary: RunSummary,
    exit_response: Any,
    *,
    exit_action_accepted: bool,
    manual_abort_required: bool,
    run_error: BaseException | None,
) -> None:
    data = summary.as_dict()
    data["exit_response"] = exit_response
    data["policy_completed"] = summary.completed_normally
    data["exit_action_accepted"] = exit_action_accepted
    data["exit_response_verified"] = exit_response is not None
    data["manual_abort_required"] = manual_abort_required
    data["overall_success"] = bool(
        summary.completed_normally
        and exit_action_accepted
        and exit_response is not None
        and not manual_abort_required
        and run_error is None
    )
    data["run_error"] = (
        None
        if run_error is None
        else {"type": type(run_error).__name__, "message": str(run_error)}
    )
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def best_effort_error_log(logger: JsonlLogger, event: str, **fields: Any) -> None:
    """错误处置不能再被磁盘故障或二次 Ctrl+C 打断。"""

    try:
        logger.write(event, **fields)
    except BaseException as log_error:
        try:
            print(f"本地日志写入失败：{type(log_error).__name__}: {log_error}")
        except BaseException:
            pass


def run_live_practice(config_path: Path, config: dict[str, Any], case_code: str) -> int:
    if not config["allow_live_practice"]:
        raise SystemExit(
            "实时门禁仍为 false。先完成离线测试并确认模拟器位于问题3演练页面，"
            "再把 config.json 中 allow_live_practice 改为 true。"
        )
    case_code = case_code.strip().upper()
    if not re.fullmatch(r"[A-Z0-9]{4}(?:-[A-Z0-9]{4}){3}", case_code):
        raise SystemExit(
            "--case-code 必须填写数据准备完成后界面显示的四组实际测试案例编码，"
            "例如 AB12-CD34-EF56-GH78"
        )
    if case_code == "XXXX-XXXX-XXXX-XXXX":
        raise SystemExit("不能使用数据准备阶段的 XXXX 占位符；请等待实际案例编码")
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise SystemExit("实时演练必须在人工交互终端中运行，禁止通过管道自动确认")
    if any(ord(character) < 32 or ord(character) == 127 for character in case_code):
        raise SystemExit("测试案例编码不能包含控制字符")

    settings = ClientSettings(
        robot_id=config["robot_id"],
        port=config["port"],
        timeout_s=config["timeout_s"],
        network_retries=config["network_retries"],
    )
    settings.validate()
    require_practice_confirmation(case_code)
    # 先消耗一次性配置门禁，再执行任何网络操作；历史命令不能直接重跑。
    consume_live_gate(config_path, config)

    tag = safe_case_tag(case_code)
    session_tag = f"{tag[:18]}-{uuid.uuid4().hex[:8]}"
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    log_directory = Path(config.get("log_directory", "logs"))
    if not log_directory.is_absolute():
        log_directory = config_path.resolve().parent / log_directory
    log_path = log_directory / f"practice-p3-{tag}-{timestamp}.jsonl"
    summary_path = log_directory / f"practice-p3-{tag}-{timestamp}-summary.json"
    logger = JsonlLogger(log_path, case_code=case_code)
    logger.write(
        "practice_gate_confirmed",
        config_path=config_path.resolve(),
        base_url=f"http://127.0.0.1:{settings.port}",
        strategy=SearchFirstPolicy.name,
        live_gate_reset_to_false=True,
    )

    client = SimulatorClient(settings, logger, session_tag=session_tag)
    policy: SearchFirstPolicy | None = None
    summary: RunSummary | None = None
    exit_response: Any = None
    run_error: BaseException | None = None

    try:
        enter_response = client.enter()
        print(
            "已进入问题3演练接口；本局实际剩余现实时间："
            f"{enter_response['remaining_real_duration_s']} 秒"
        )
        policy = SearchFirstPolicy(client, logger, enter_response)
        summary = policy.run()
        print(
            f"策略结束：发现 {len(summary.discovered_channels)} 个频道，"
            f"清除 {len(summary.cleared_channels)} 个频道，"
            f"虚拟时间 {summary.final_virtual_time_s:.6f} 秒。"
        )
    except KeyboardInterrupt as error:
        run_error = error
        best_effort_error_log(logger, "run_interrupted", reason="KeyboardInterrupt")
        print("收到键盘中断。")
    except BaseException as error:
        run_error = error
        best_effort_error_log(logger, "run_failed", error=error)
        print(f"演练程序停止：{type(error).__name__}: {error}")
    finally:
        if client.entered and not client.closed:
            if client.action_state_certain:
                try:
                    exit_response = client.exit()
                    print("已正常发送 /exit。")
                except BaseException as exit_error:
                    best_effort_error_log(logger, "exit_failed", error=exit_error)
                    print(f"/exit 失败：{type(exit_error).__name__}: {exit_error}")
                    if run_error is None:
                        run_error = exit_error
            else:
                # 统一在 finally 之后给出一次人工处置提示。
                pass

    manual_abort_required = (not client.action_state_certain) or (
        client.entered and not client.closed
    )
    if manual_abort_required:
        print(
            "重要：/enter 或最后一个动作可能已经执行，程序按照协议没有发送"
            "不同的新动作。请先确认客户端已停止，再核对当前会话标题仍为"
            "“问题3演练测试”，然后在该演练页面点击红色“中止测试”并完成"
            "两次确认。"
        )

    if summary is None and policy is not None:
        summary = policy.interrupted_summary(
            f"{type(run_error).__name__}: {run_error}" if run_error else "未知中断"
        )
    if summary is not None:
        write_summary(
            summary_path,
            summary,
            exit_response,
            exit_action_accepted=client.closed,
            manual_abort_required=manual_abort_required,
            run_error=run_error,
        )
        print(f"结果摘要：{summary_path}")
    print(f"明文日志：{log_path}")

    if manual_abort_required:
        return 3
    return 0 if run_error is None else 2


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="CUMCM 2026 B题问题3演练客户端")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument(
        "--live-practice",
        action="store_true",
        help="经过三重门禁后连接本机问题3演练接口；省略时只做离线检查",
    )
    parser.add_argument(
        "--case-code",
        default="",
        help="模拟器问题3演练页面显示的测试案例编码，仅写入本地日志",
    )
    return parser.parse_args()


def main() -> int:
    arguments = parse_args()
    config_path = arguments.config.resolve()
    config = load_config(config_path)
    if not arguments.live_practice:
        print_dry_run(config_path, config)
        return 0
    return run_live_practice(config_path, config, arguments.case_code)


if __name__ == "__main__":
    sys.exit(main())
