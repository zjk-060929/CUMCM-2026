from __future__ import annotations

import math
import unittest

import numpy as np

from geometry import (
    Observation,
    conservative_clear_route,
    coverage_stations,
    minimax_coverage_radius,
    second_detection_candidates,
    worst_coverage_distance,
)


class GeometryTests(unittest.TestCase):
    def test_minimax_seven_point_radius(self) -> None:
        expected = 1800.0 / (2.0 * math.cos(math.pi / 7.0))
        self.assertAlmostEqual(minimax_coverage_radius(), expected, places=10)
        self.assertLess(worst_coverage_distance(), 1000.0)
        self.assertEqual(len(coverage_stations()), 7)

    def test_second_candidates_are_exactly_1000_m_away(self) -> None:
        observation = Observation(123.0, -456.0, 37.25)
        for point in second_detection_candidates(observation):
            self.assertAlmostEqual(
                float(np.linalg.norm(point - observation.point)), 1000.0, places=8
            )

    def test_clear_grid_covers_bounding_rectangle(self) -> None:
        polygon = np.array(
            [[-61.0, -44.0], [72.0, -44.0], [72.0, 53.0], [-61.0, 53.0]]
        )
        route, _ = conservative_clear_route(polygon, np.array([0.0, 0.0]))
        for x in np.linspace(-61.0, 72.0, 80):
            for y in np.linspace(-44.0, 53.0, 70):
                nearest = min(float(np.linalg.norm(np.array([x, y]) - point)) for point in route)
                self.assertLessEqual(nearest, 20.0 + 1.0e-8)

    def test_small_enclosing_circle_still_has_grid_fallback(self) -> None:
        polygon = np.array(
            [[-20.0, -0.1], [20.0, -0.1], [20.0, 0.1], [-20.0, 0.1]]
        )
        route, radius = conservative_clear_route(polygon, np.array([0.0, 0.0]))
        self.assertLessEqual(radius, 20.001)
        self.assertGreater(len(route), 1)


if __name__ == "__main__":
    unittest.main()
