from __future__ import annotations

import hashlib
import math
import tempfile
import time
import unittest
from pathlib import Path

import numpy as np

from policy import PolicyError, SearchFirstPolicy
from protocol import JsonlLogger


class OfflineSimulatorClient:
    """仅供单元测试的内存环境，不创建监听端口。"""

    worst_case_request_wait_s = 0.01

    def __init__(self, source_count: int = 10):
        self.position = np.zeros(2)
        self.receiver_channel = 1
        self.virtual_time_s = 0.0
        self.sources = {}
        golden_angle = math.pi * (3.0 - math.sqrt(5.0))
        for index, channel in enumerate(range(1, source_count + 1)):
            radius = 260.0 + 80.0 * index
            angle = index * golden_angle
            self.sources[channel] = radius * np.array([math.cos(angle), math.sin(angle)])
        self.cleared = set()
        self.last_action_started_monotonic_s = time.monotonic()

    def _move(self, x: float, y: float) -> np.ndarray:
        target = np.array([x, y], dtype=float)
        self.virtual_time_s += float(np.linalg.norm(target - self.position)) / 5.0
        self.position = target
        return target

    @staticmethod
    def _error(channel: int, point: np.ndarray) -> float:
        key = f"{channel}:{point[0]:.6f}:{point[1]:.6f}".encode()
        digest = hashlib.blake2b(key, digest_size=8).digest()
        unit = int.from_bytes(digest, "big") / float(2**64 - 1)
        return 1.8 * unit - 0.9

    def measure(self, x: float, y: float, channel: int):
        point = self._move(x, y)
        if channel != self.receiver_channel:
            self.virtual_time_s += 1.0
        self.receiver_channel = channel
        self.virtual_time_s += 5.0
        source = self.sources.get(channel)
        if source is None or channel in self.cleared:
            result = "no_signal"
            extra = {}
        else:
            distance = float(np.linalg.norm(source - point))
            if distance > 1000.0 + 1.0e-9:
                result = "no_signal"
                extra = {}
            elif distance <= 5.0:
                result = "near"
                extra = {}
            else:
                result = "direction"
                bearing = math.degrees(math.atan2(source[1] - point[1], source[0] - point[0]))
                bearing = round((bearing + self._error(channel, point)) % 360.0, 2) % 360.0
                extra = {"svd_deg": bearing}
        return {
            "accepted": True,
            "real_timestamp_ms": 1,
            "virtual_time_s": self.virtual_time_s,
            "measure_result": result,
            **extra,
        }

    def clear(self, x: float, y: float, channel: int):
        point = self._move(x, y)
        source = self.sources.get(channel)
        success = (
            source is not None
            and channel not in self.cleared
            and float(np.linalg.norm(source - point)) <= 20.0 + 1.0e-9
        )
        self.virtual_time_s += 5.0 if success else 3.0
        if success:
            self.cleared.add(channel)
        return {
            "accepted": True,
            "real_timestamp_ms": 1,
            "virtual_time_s": self.virtual_time_s,
            "clear_result": "success" if success else "no_target_in_range",
        }


class OfflinePolicyTests(unittest.TestCase):
    def test_search_first_clears_ten_hidden_sources_without_truth_access(self) -> None:
        client = OfflineSimulatorClient()
        enter_response = {
            "remaining_real_duration_s": 1200,
            "max_virtual_duration_s": 360000,
        }
        with tempfile.TemporaryDirectory() as directory:
            logger = JsonlLogger(Path(directory) / "offline.jsonl", "offline")
            policy = SearchFirstPolicy(client, logger, enter_response)  # type: ignore[arg-type]
            summary = policy.run()
        self.assertTrue(summary.completed_normally)
        self.assertEqual(summary.discovered_channels, tuple(range(1, 11)))
        self.assertEqual(summary.cleared_channels, tuple(range(1, 11)))
        self.assertEqual(client.cleared, set(range(1, 11)))
        self.assertLess(summary.final_virtual_time_s, 360000)

    def test_fewer_than_ten_discoveries_is_not_reported_as_success(self) -> None:
        client = OfflineSimulatorClient(source_count=9)
        with tempfile.TemporaryDirectory() as directory:
            logger = JsonlLogger(Path(directory) / "offline.jsonl", "offline")
            policy = SearchFirstPolicy(
                client,  # type: ignore[arg-type]
                logger,
                {
                    "remaining_real_duration_s": 1200,
                    "max_virtual_duration_s": 360000,
                },
            )
            with self.assertRaises(PolicyError):
                policy.run()

    def test_sixteen_sources_trigger_valid_early_stop(self) -> None:
        client = OfflineSimulatorClient(source_count=16)
        with tempfile.TemporaryDirectory() as directory:
            logger = JsonlLogger(Path(directory) / "offline.jsonl", "offline")
            policy = SearchFirstPolicy(
                client,  # type: ignore[arg-type]
                logger,
                {
                    "remaining_real_duration_s": 1200,
                    "max_virtual_duration_s": 360000,
                },
            )
            summary = policy.run()
        self.assertEqual(len(summary.discovered_channels), 16)
        self.assertEqual(len(summary.cleared_channels), 16)


if __name__ == "__main__":
    unittest.main()
