"""问题 3 演练策略使用的纯几何函数。

只处理可观测的测向结果，不包含、也不能访问干扰源真实坐标。
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass
from typing import Sequence

import numpy as np


EPS = 1.0e-10
REGION_RADIUS_M = 1800.0
MIN_RECEPTION_RADIUS_M = 1000.0
MAX_RECEPTION_RADIUS_M = 1500.0
BEARING_ERROR_DEG = 1.0
CLEAR_RADIUS_M = 20.0
CIRCLE_APPROXIMATION_SIDES = 128

SECOND_FORWARD_M = 9000.0 / 11.0
SECOND_LATERAL_M = 2000.0 * math.sqrt(10.0) / 11.0


class GeometryError(RuntimeError):
    """定位区域为空、无界或数值退化。"""


@dataclass(frozen=True)
class Observation:
    x: float
    y: float
    bearing_deg: float

    @property
    def point(self) -> np.ndarray:
        return np.array([self.x, self.y], dtype=float)


@dataclass(frozen=True)
class DirectedLine:
    point: np.ndarray
    direction: np.ndarray
    angle: float


def cross2(first: np.ndarray, second: np.ndarray) -> float:
    return float(first[0] * second[1] - first[1] * second[0])


def make_line(point: np.ndarray, direction: np.ndarray) -> DirectedLine:
    point = np.asarray(point, dtype=float)
    direction = np.asarray(direction, dtype=float)
    norm = float(np.linalg.norm(direction))
    if norm <= EPS:
        raise ValueError("直线方向向量不能为零")
    direction = direction / norm
    return DirectedLine(
        point=point,
        direction=direction,
        angle=math.atan2(float(direction[1]), float(direction[0]))
        % (2.0 * math.pi),
    )


def point_inside(line: DirectedLine, point: np.ndarray, eps: float = EPS) -> bool:
    return cross2(line.direction, np.asarray(point, dtype=float) - line.point) >= -eps


def line_intersection(
    first: DirectedLine, second: DirectedLine, eps: float = EPS
) -> np.ndarray | None:
    denominator = cross2(first.direction, second.direction)
    if abs(denominator) <= eps:
        return None
    parameter = cross2(second.point - first.point, second.direction) / denominator
    return first.point + parameter * first.direction


def bearing_halfplanes(
    observations: Sequence[Observation], error_deg: float = BEARING_ERROR_DEG
) -> list[DirectedLine]:
    if not observations:
        raise ValueError("至少需要一次示向度观测")
    lines: list[DirectedLine] = []
    for observation in observations:
        lower = math.radians(observation.bearing_deg - error_deg)
        upper = math.radians(observation.bearing_deg + error_deg)
        lower_direction = np.array([math.cos(lower), math.sin(lower)])
        upper_direction = np.array([math.cos(upper), math.sin(upper)])
        lines.append(make_line(observation.point, lower_direction))
        lines.append(make_line(observation.point, -upper_direction))
    return lines


def circle_outer_halfplanes(
    center: np.ndarray,
    radius: float,
    sides: int = CIRCLE_APPROXIMATION_SIDES,
) -> list[DirectedLine]:
    """用外切正多边形包住圆盘，保证不会排除真实源。"""

    center = np.asarray(center, dtype=float)
    result: list[DirectedLine] = []
    for index in range(sides):
        angle = 2.0 * math.pi * index / sides
        normal = np.array([math.cos(angle), math.sin(angle)])
        tangent_point = center + radius * normal
        tangent_direction = np.array([-math.sin(angle), math.cos(angle)])
        result.append(make_line(tangent_point, tangent_direction))
    return result


def _remove_same_direction_parallel_lines(
    lines: Sequence[DirectedLine], eps: float
) -> list[DirectedLine]:
    ordered = sorted(lines, key=lambda line: line.angle)
    unique: list[DirectedLine] = []
    for line in ordered:
        if unique:
            previous = unique[-1]
            parallel = abs(cross2(previous.direction, line.direction)) <= eps
            same_direction = float(np.dot(previous.direction, line.direction)) > 0.0
            if parallel and same_direction:
                if cross2(previous.direction, line.point - previous.point) > eps:
                    unique[-1] = line
                continue
        unique.append(line)
    return unique


def _required_intersection(
    first: DirectedLine, second: DirectedLine, eps: float
) -> np.ndarray:
    point = line_intersection(first, second, eps)
    if point is None:
        raise GeometryError("定位边界出现无法闭合的平行线")
    return point


def signed_polygon_area(vertices: np.ndarray) -> float:
    x = vertices[:, 0]
    y = vertices[:, 1]
    return 0.5 * float(np.sum(x * np.roll(y, -1) - y * np.roll(x, -1)))


def half_plane_intersection(
    lines: Sequence[DirectedLine], eps: float = EPS
) -> np.ndarray:
    if len(lines) < 3:
        raise GeometryError("半平面数量不足")
    ordered = _remove_same_direction_parallel_lines(lines, eps)
    active: deque[DirectedLine] = deque()

    for line in ordered:
        while len(active) >= 2:
            tail = _required_intersection(active[-2], active[-1], eps)
            if point_inside(line, tail, eps):
                break
            active.pop()
        while len(active) >= 2:
            head = _required_intersection(active[0], active[1], eps)
            if point_inside(line, head, eps):
                break
            active.popleft()
        active.append(line)

    while len(active) >= 3:
        tail = _required_intersection(active[-2], active[-1], eps)
        if point_inside(active[0], tail, eps):
            break
        active.pop()
    while len(active) >= 3:
        head = _required_intersection(active[0], active[1], eps)
        if point_inside(active[-1], head, eps):
            break
        active.popleft()

    if len(active) < 3:
        raise GeometryError("测向信息没有形成有界定位区域")

    active_lines = list(active)
    polygon = np.asarray(
        [
            _required_intersection(
                active_lines[index], active_lines[(index + 1) % len(active_lines)], eps
            )
            for index in range(len(active_lines))
        ]
    )
    if any(
        not point_inside(line, vertex, 100.0 * eps)
        for vertex in polygon
        for line in ordered
    ):
        raise GeometryError("半平面没有形成有效闭合区域")

    filtered: list[np.ndarray] = []
    for vertex in polygon:
        if not filtered or np.linalg.norm(vertex - filtered[-1]) > 100.0 * eps:
            filtered.append(vertex)
    if len(filtered) > 1 and np.linalg.norm(filtered[0] - filtered[-1]) <= 100.0 * eps:
        filtered.pop()
    polygon = np.asarray(filtered, dtype=float)
    if len(polygon) < 3 or abs(signed_polygon_area(polygon)) <= eps:
        raise GeometryError("定位区域退化为点或线段")
    if signed_polygon_area(polygon) < 0:
        polygon = polygon[::-1].copy()
    return polygon


TARGET_REGION_LINES = circle_outer_halfplanes(
    np.zeros(2), REGION_RADIUS_M, CIRCLE_APPROXIMATION_SIDES
)


def localization_polygon(observations: Sequence[Observation]) -> np.ndarray:
    if len(observations) < 2:
        raise GeometryError("至少需要两次有效示向度才能定位")
    lines = list(TARGET_REGION_LINES)
    lines.extend(bearing_halfplanes(observations))
    for observation in observations:
        # 能收到信号可推出真实源到检测点不超过其接收半径，而该半径至多 1500 m。
        lines.extend(
            circle_outer_halfplanes(
                observation.point,
                MAX_RECEPTION_RADIUS_M,
                CIRCLE_APPROXIMATION_SIDES,
            )
        )
    return half_plane_intersection(lines)


def minimax_coverage_radius() -> float:
    """七个等角覆盖点使最坏最近距离最小的解析半径。"""

    return REGION_RADIUS_M / (2.0 * math.cos(math.pi / 7.0))


def coverage_stations() -> list[np.ndarray]:
    radius = minimax_coverage_radius()
    return [
        radius
        * np.array(
            [math.cos(2.0 * math.pi * index / 7.0), math.sin(2.0 * math.pi * index / 7.0)]
        )
        for index in range(7)
    ]


def worst_coverage_distance() -> float:
    radius = minimax_coverage_radius()
    boundary = math.sqrt(
        REGION_RADIUS_M**2
        + radius**2
        - 2.0 * REGION_RADIUS_M * radius * math.cos(math.pi / 7.0)
    )
    return max(radius, boundary)


def second_detection_candidates(observation: Observation) -> tuple[np.ndarray, np.ndarray]:
    angle = math.radians(observation.bearing_deg)
    forward = np.array([math.cos(angle), math.sin(angle)])
    lateral = np.array([-math.sin(angle), math.cos(angle)])
    base = observation.point + SECOND_FORWARD_M * forward
    return (
        base + SECOND_LATERAL_M * lateral,
        base - SECOND_LATERAL_M * lateral,
    )


def ordered_second_detection_candidates(
    current_position: np.ndarray, observation: Observation
) -> tuple[np.ndarray, np.ndarray]:
    candidates = second_detection_candidates(observation)
    return tuple(
        sorted(
            candidates,
            key=lambda point: float(np.linalg.norm(point - current_position)),
        )
    )  # type: ignore[return-value]


def _circle_two(first: np.ndarray, second: np.ndarray) -> tuple[np.ndarray, float]:
    center = 0.5 * (first + second)
    return center, float(np.linalg.norm(first - center))


def _circle_three(
    first: np.ndarray, second: np.ndarray, third: np.ndarray
) -> tuple[np.ndarray, float] | None:
    ax, ay = first
    bx, by = second
    cx, cy = third
    determinant = 2.0 * (
        ax * (by - cy) + bx * (cy - ay) + cx * (ay - by)
    )
    if abs(determinant) <= 1.0e-12:
        return None
    ux = (
        (ax * ax + ay * ay) * (by - cy)
        + (bx * bx + by * by) * (cy - ay)
        + (cx * cx + cy * cy) * (ay - by)
    ) / determinant
    uy = (
        (ax * ax + ay * ay) * (cx - bx)
        + (bx * bx + by * by) * (ax - cx)
        + (cx * cx + cy * cy) * (bx - ax)
    ) / determinant
    center = np.array([ux, uy])
    return center, float(np.linalg.norm(first - center))


def _contains(circle: tuple[np.ndarray, float], point: np.ndarray) -> bool:
    center, radius = circle
    return float(np.linalg.norm(point - center)) <= radius + 1.0e-7 * max(1.0, radius)


def minimum_enclosing_circle(points: np.ndarray) -> tuple[np.ndarray, float]:
    data = np.asarray(points, dtype=float)
    if len(data) == 0:
        raise ValueError("点集不能为空")
    # 固定顺序保证不同机器得到相同结果。
    order = data[np.random.default_rng(20260911 + len(data)).permutation(len(data))]
    circle: tuple[np.ndarray, float] | None = None
    for index, first in enumerate(order):
        if circle is not None and _contains(circle, first):
            continue
        circle = (first.copy(), 0.0)
        for second_index, second in enumerate(order[:index]):
            if _contains(circle, second):
                continue
            circle = _circle_two(first, second)
            for third in order[:second_index]:
                if _contains(circle, third):
                    continue
                triple = _circle_three(first, second, third)
                if triple is not None:
                    circle = triple
                else:
                    pairs = [
                        _circle_two(first, second),
                        _circle_two(first, third),
                        _circle_two(second, third),
                    ]
                    circle = min(
                        (
                            candidate
                            for candidate in pairs
                            if all(
                                _contains(candidate, point)
                                for point in (first, second, third)
                            )
                        ),
                        key=lambda candidate: candidate[1],
                    )
    assert circle is not None
    return circle


def _grid_axis(minimum: float, maximum: float) -> np.ndarray:
    width = maximum - minimum
    if width <= EPS:
        return np.array([(minimum + maximum) / 2.0])
    # 每格半对角线严格小于 20 m；1e-6 只抵消浮点边界误差。
    maximum_side = math.sqrt(2.0) * (CLEAR_RADIUS_M - 1.0e-6)
    count = max(1, int(math.ceil(width / maximum_side)))
    return minimum + (np.arange(count) + 0.5) * width / count


def _serpentine_routes(xs: np.ndarray, ys: np.ndarray) -> list[np.ndarray]:
    routes: list[np.ndarray] = []
    for reverse_y in (False, True):
        points: list[list[float]] = []
        ordered_y = ys[::-1] if reverse_y else ys
        for row, y in enumerate(ordered_y):
            ordered_x = xs[::-1] if row % 2 else xs
            points.extend([[float(x), float(y)] for x in ordered_x])
        route = np.asarray(points, dtype=float)
        routes.append(route)
        routes.append(route[::-1].copy())
    return routes


def route_length(start: np.ndarray, points: np.ndarray) -> float:
    if len(points) == 0:
        return 0.0
    total = float(np.linalg.norm(points[0] - start))
    if len(points) > 1:
        total += float(np.sum(np.linalg.norm(np.diff(points, axis=0), axis=1)))
    return total


def conservative_clear_route(
    polygon: np.ndarray, current_position: np.ndarray
) -> tuple[np.ndarray, float]:
    """返回先试最小包围圆圆心、再覆盖包围盒的清除点序列。"""

    center, radius = minimum_enclosing_circle(polygon)
    minimum = np.min(polygon, axis=0)
    maximum = np.max(polygon, axis=0)
    xs = _grid_axis(float(minimum[0]), float(maximum[0]))
    ys = _grid_axis(float(minimum[1]), float(maximum[1]))
    routes = _serpentine_routes(xs, ys)
    route = min(routes, key=lambda points: route_length(center, points))
    route = np.asarray(
        [point for point in route if np.linalg.norm(point - center) > 1.0e-7],
        dtype=float,
    )
    if route.size == 0:
        return np.asarray([center]), radius
    return np.vstack([center, route]), radius
